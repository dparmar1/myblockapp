﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ChainCodeController', ChainCodeController);

    ChainCodeController.$inject = ['UserService', '$location', '$rootScope', 'FlashService','$http'];
    function ChainCodeController(UserService, $location, $rootScope, FlashService, Http) {
        var vm = this;

        vm.runChainCode = runChainCode;

        
        
        function runChainCode(){
        	
        	var data = {
        			  "jsonrpc": "2.0",
        			  "method": "query",
        			  "params": {
        			    "type": 1,
        			    "chaincodeID": {
        			      "name": "da590bc4002ae0bf396bcaeefef47e4ce8a5487139a81a992c0d9d358244f75ef2312bf12fa39c9a6662d1d95d42208c0d2bfe5c1157dc157c39b7cd29d1cda9"
        			    },
        			    "ctorMsg": {
        			      "function": "read",
        			      "args": [
        			        "hello_world"
        			      ]
        			    },
        			    "secureContext": "user_type1_0"
        			  },
        			  "id": 0
        			};

		
        	Http.post("https://971e68928091477481be89563c1fe4c4-vp0.us.blockchain.ibm.com:5002/chaincode", JSON.stringify(data), {headers: {'Content-Type': 'application/json'} })
            .then(function (response) {
            	console.log(response);                
            });
        	
        }
    }

})();
