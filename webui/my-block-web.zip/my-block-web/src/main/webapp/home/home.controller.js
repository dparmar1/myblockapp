﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['UserService', '$rootScope', '$http'];
    function HomeController(UserService, $rootScope, $http) {
        var vm = this;

        vm.user = null;
        
        

        initController();

        function initController() {
            loadCurrentUser();
            
        }

        function loadCurrentUser() {
            GetUserById("1")
                .then(function (user) {
                    console.log(user);
                });
        }
        
        function GetUserById(id) {
        	var args = [id]; 
        	var bchain_userID = "user_type1_0";
        	var peer0url = "https://be261e91fb1f41ca8e637a4188e141b6-vp0.us.blockchain.ibm.com:5001 /chaincode";
           
            var header = {'Content-Type': 'application/json'}; 
        	var requestObj = getRequestObject("query", "user_detail", args, bchain_userID);
        	return $http.post(peer0url, JSON.stringify(requestObj), header )
        	.then(handleSuccess, handleError('Error creating user'));       	
        	
        }
        
        function getRequestObject(method, funcName, args, user1) {
        	
       	 var chaincodeID = "2694392e21923c7f5fa7ce87c28f2e732a049cf603e2b49bef7f418e218a59c2241d5978cbb9224fc4f912c2910c86988f50a04bcad35f7729c5f89c85c7e9b0";
      	 var data = {
        			  "jsonrpc": "2.0",
      			  "method": method,
      			  "params": {
      			    "type": 1,
      			    "chaincodeID": {
      			      "name": chaincodeID
      			    },
      			    "ctorMsg": {
      			      "function": funcName,
      			      "args": args
      			    },
      			    "secureContext": user1
      			  },
      			  "id": 0
      			};
       	 
       	 return data;
       }
        
        function handleSuccess(res) {
            return res.data;
        }
        
        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }

        
    }

})();