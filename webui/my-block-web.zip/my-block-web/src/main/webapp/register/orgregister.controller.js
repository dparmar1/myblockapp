﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('OrgRegisterController', OrgRegisterController);

    OrgRegisterController.$inject = ['UserService', '$location', '$rootScope', 'FlashService','$http'];
    function OrgRegisterController(UserService, $location, $rootScope, FlashService, Http) {
        var vm = this;

        vm.register = register;
        vm.runChainCode = runChainCode;

        function register() {
            vm.dataLoading = true;
            UserService.Create(vm.user)
                .then(function (response) {
                    if (response.success) {
                        FlashService.Success('Registration successful', true);
                        $location.path('/login');
                    } else {
                        FlashService.Error(response.message);
                        vm.dataLoading = false;
                    }
                });
        }
        
        function runChainCode(){
        	alert("in");
        	var data = {
        			  "jsonrpc": "2.0",
        			  "method": "query",
        			  "params": {
        			    "type": 1,
        			    "chaincodeID": {
        			      "name": "da590bc4002ae0bf396bcaeefef47e4ce8a5487139a81a992c0d9d358244f75ef2312bf12fa39c9a6662d1d95d42208c0d2bfe5c1157dc157c39b7cd29d1cda9"
        			    },
        			    "ctorMsg": {
        			      "function": "read",
        			      "args": [
        			        "hello_world"
        			      ]
        			    },
        			    "secureContext": "user_type1_0"
        			  },
        			  "id": 0
        			};

		
        	Http.post("https://971e68928091477481be89563c1fe4c4-vp0.us.blockchain.ibm.com:5002", JSON.stringify(data), {headers: {'Content-Type': 'application/json'} })
            .then(function (response) {
            	alert(response);
                return response;
            });
        }
        
    }

})();
