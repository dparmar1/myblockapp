﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('UserService', UserService);

    UserService.$inject = ['$http'];
    function UserService($http) {
        var service = {};
        
        service.peer0url = "https://be261e91fb1f41ca8e637a4188e141b6-vp0.us.blockchain.ibm.com:5001 /chaincode";
        service.peer1url = "";
        service.peer2url = "";
        service.header = {'Content-Type': 'application/json'}; 

        
        service.GetByUsername = GetByUsername;
        service.GetUserById = GetUserById;
        service.CreateUser = CreateUser;
        service.UpdateUser = UpdateUser;
        
        service.GetByOrgById = GetByOrgById;
        service.CreateOrg = CreateOrg;
        service.UpdateOrg = UpdateOrg;
        
        service.CreateApprovalRequest = CreateApprovalRequest;
        service.CreateReviewRequest = CreateReviewRequest;

        return service;

        
        function GetUserById(id) {
        	var args = [id]; 
        	var bchain_userID = "user_type1_0";
        	var requestObj = getRequestObject("query", "user_detail", user.args, user.id);
        	return $http.post(service.peer0url, JSON.stringify(requestObj), service.header )
        	.then(handleSuccess, handleError('Error creating user'));       	
        	
        }
        
        function GetByOrgById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }

        function GetByUsername(username) {
        	console.log("In GetByUsername");
        	var user = {};
        	user.password = "";
        	if(username == "user01" ){
        		user.password = "user01passwd";
        	} else if(username == "org01"){
        		user.password = "org01passwd";
        	} else if(username == "org02") {
        		user.password = "org02passwd";
        	}
        	
            return user;
            //return $http.get('/api/users/' + username).then(handleSuccess, handleError('Error getting user by username'));
        }

        function CreateUser(user) {
        	var args = [user.username, user.firstname, user.lastname, user.birthdate, user.pannumber]; 
        	var bchain_userID = "";
        	var requestObj = getRequestObject("invoke", "addUser", args, bchain_userID);
        	return $http.post(service.peer0url, JSON.stringify(requestObj),service.header)
        	.then(handleSuccess, handleError('Error creating user'));            
        }

        function UpdateUser(user) {
            return $http.put('/api/users/' + user.id, user).then(handleSuccess, handleError('Error updating user'));
        }
        
        function CreateOrg(user) {
            return $http.post('/api/users', user).then(handleSuccess, handleError('Error creating user'));
        }

        function UpdateOrg(user) {
            return $http.put('/api/users/' + user.id, user).then(handleSuccess, handleError('Error updating user'));
        }
        
        function CreateReviewRequest() {
        	
        }
        
        function CreateApprovalRequest() {
        	
        }

       

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
        
        function getRequestObject(method, funcName, args, user) {
        	
        	 var chaincodeID = "2694392e21923c7f5fa7ce87c28f2e732a049cf603e2b49bef7f418e218a59c2241d5978cbb9224fc4f912c2910c86988f50a04bcad35f7729c5f89c85c7e9b0";
              
                        
             
        	 var data = {
         			  "jsonrpc": "2.0",
       			  "method": method,
       			  "params": {
       			    "type": 1,
       			    "chaincodeID": {
       			      "name": chaincodeID
       			    },
       			    "ctorMsg": {
       			      "function": funcName,
       			      "args": args
       			    },
       			    "secureContext": user
       			  },
       			  "id": 0
       			};
        	 
        	 return data;
        }
    }

})();
