﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('BlockChainService', BlockChainService);

    BlockChainService.$inject = ['$http'];
    function BlockChainService($http) {
        var service = {};
        
        service.data = {};
        service.header = {};
        service.url = {};

        
        service.GetByUsername = GetByUsername;
        service.GetUserDetails = GetUserDetails;
        service.CreateUser = CreateUser;
        service.UpdateUser = UpdateUser;
        
        service.GetOrgDetails = GetOrgDetails;
        service.CreateOrg = CreateOrg;
        service.UpdateOrg = UpdateOrg;
        

        return service;
     

        function GetById(id) {
            return $http.get('/api/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
        }

        function GetByUsername(username) {
        	var user = {};
        	user.password = "";
        	if(username == "user01" ){
        		user.password = "user01passwd";
        	} else if(username == "org01"){
        		user.password = "org01passwd";
        	} else if(username == "org02") {
        		user.password = "org02passwd";
        	}
            return user;
        }

        function CreateUser(user) {
            return $http.post('/api/users', user).then(handleSuccess, handleError('Error creating user'));
        }

        function UpdateUser(user) {
            return $http.put('/api/users/' + user.id, user).then(handleSuccess, handleError('Error updating user'));
        }

        

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(error) {
            return function () {
                return { success: false, message: error };
            };
        }
    }

})();
